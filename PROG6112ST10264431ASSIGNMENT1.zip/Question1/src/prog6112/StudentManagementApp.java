/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog6112;
import java.util.ArrayList;
import java.util.Scanner;

public class StudentManagementApp {

    private static ArrayList<Student> students = new ArrayList<>();
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        boolean running = true;
        
        while (running){
        displayMenu();
        String choice = scanner.nextLine();
        switch (choice){
            case "1":
                cauptureNewStudent(scanner);
                break;
            case "2":
                searchStudent(scanner);
                break;
            case "3":
                deleteStudent(scanner);
                break;
            case "4":
                printStudentReport();
                break;
            case "5":
                running = false;
                System.out.println("Exiting the application.");
                break;
            default:
                System.out.println("Invalid option. Please try again.");      
         }
        }
        scanner.close();
    }
    private static void displayMenu() {
        System.out.println("STUDENT MANAGEMENT APPLICATION"); 
        System.out.println("================================");
        System.out.println("(1)Capture a new student");
        System.out.println("(2)Search for a student");
        System.out.println("(3) Delete a student");
        System.out.println("(4) Print student report");
        System.out.println("(5) Exit Application");
        System.out.println("Please select one of the above options: ");
    }
    
    private static void cauptureNewStudent(Scanner scanner) {
        System.out.println("CAPTURE A NEW STUDENT");
        System.out.println("================================");
        System.out.println("Enter student id: ");
        String id = scanner.nextLine();
        
        System.out.println("Enter the student name: ");
        String name = scanner.nextLine();
        
        int age = 0;
        while (true) {
            System.out.print("Enter the student age: ");
            try {
            age = Integer.parseInt(scanner.nextLine());
            if (age >= 16){
                break;
            }else{
                System.out.println("Invalid age. Age must be 16 or older.");
            }
            }catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number for age.");
            }
        }
        
        System.out.print("Enter the student email: ");
        String email = scanner.nextLine();
        
        System.out.print("Enter the student course: ");
        String course = scanner.nextLine();
        
        Student newStudent = new Student(id, name, age, email, course);
        students.add(newStudent);
        System.out.println("Student added successfully.");
    }

    private static void searchStudent(Scanner scanner) {
        System.out.print("Enter the student id you are looking for: ");
        String id = scanner.nextLine();
        
        for (Student student : students) {
            if (student.getId().equals(id)) {
                System.out.println("Student found: " + student);
                return;
            }
        }
        System.out.println("Student not found.");
    }

    private static void deleteStudent(Scanner scanner) {
        System.out.print("Enter the student id to delete: ");
        String id = scanner.nextLine();
        
        for (Student student : students) {
            if (student.getId().equals(id)) {
                students.remove(student);
                System.out.println("Student has successfully been deleted.");
                return;
            }
        }
        System.out.println("Student not found.");
    }

    private static void printStudentReport() {
        if (students.isEmpty()) {
            System.out.println("No students to display.");
        } else {
            System.out.println("STUDENT REPORT:");
            System.out.println("================================");
            for (Student student: students) {
                System.out.println(student);
            }
        }
    }
}

