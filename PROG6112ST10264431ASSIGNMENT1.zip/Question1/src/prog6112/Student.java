/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog6112;

class Student {
        private String id;
        private String name;
        private int age;
        private String email;
        private String course;
    
    public Student(String id, String name, int age, String email, String course){
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
        }
    public String getId() {
        return id;
    }
    
    @Override
        public String toString(){
        return "Student ID: " + id + ", Name: " + name + ", Age: " + age + "Email: " + email + ", Course: " + course;
    }
}
