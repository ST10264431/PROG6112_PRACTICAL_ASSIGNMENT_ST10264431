/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

public class InventoryManagementAppTest {

    private ArrayList<Product> inventory;

    @Before
    public void setUp() {
        inventory = new ArrayList<>();
    }

    @Test
    public void testAddNewElectronicProduct() {
        Electronic electronic = new Electronic("E001", "Laptop", 1200.50, 5, 24);
        inventory.add(electronic);

        assertEquals(1, inventory.size());
        assertEquals("Laptop", inventory.get(0).getName());
        assertTrue(inventory.get(0) instanceof Electronic);
    }

    @Test
    public void testAddNewGroceryProduct() {
        Grocery grocery = new Grocery("G001", "Apple", 0.99, 100, "2025-12-31");
        inventory.add(grocery);

        assertEquals(1, inventory.size());
        assertEquals("Apple", inventory.get(0).getName());
        assertEquals("2025-12-31", ((Grocery) inventory.get(0)).getExpirationDate());
        assertTrue(inventory.get(0) instanceof Grocery);
    }

    @Test
    public void testSearchProduct() {
        Electronic electronic = new Electronic("E001", "Laptop", 1200.50, 5, 24);
        inventory.add(electronic);

        Product found = null;
        for (Product product : inventory) {
            if (product.getId().equals("E001")) {
                found = product;
                break;
            }
        }

        assertNotNull(found);
        assertEquals("E001", found.getId());
        assertEquals("Laptop", found.getName());
    }

    @Test
    public void testUpdateProduct() {
        Electronic electronic = new Electronic("E001", "Laptop", 1200.50, 5, 24);
        inventory.add(electronic);

        // Updating the product's name and price
        for (Product product : inventory) {
            if (product.getId().equals("E001")) {
                product.setName("Gaming Laptop");
                product.setPrice(1500.75);
            }
        }

        assertEquals("Gaming Laptop", inventory.get(0).getName());
        assertEquals(1500.75, inventory.get(0).getPrice(), 0.001);
    }

    @Test
    public void testRemoveProduct() {
        Electronic electronic = new Electronic("E001", "Laptop", 1200.50, 5, 24);
        inventory.add(electronic);

        assertEquals(1, inventory.size());

        inventory.removeIf(product -> product.getId().equals("E001"));

        assertEquals(0, inventory.size());
    }

    @Test
    public void testDisplayInventoryReport() {
        Electronic electronic = new Electronic("E001", "Laptop", 1200.50, 5, 24);
        Grocery grocery = new Grocery("G001", "Apple", 0.99, 100, "2025-12-31");

        inventory.add(electronic);
        inventory.add(grocery);

        assertEquals(2, inventory.size());
        assertEquals("Laptop", inventory.get(0).getName());
        assertEquals("Apple", inventory.get(1).getName());
    }
}

