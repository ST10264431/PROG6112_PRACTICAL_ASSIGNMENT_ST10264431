/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
import java.util.Scanner;
import java.util.ArrayList;

public class InventoryManagementApp {
    private static ArrayList<Product> inventory = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            displayMenu();
            String choice = scanner.nextLine();
            switch (choice) {
                case "1":
                    addNewProduct(scanner);
                    break;
                case "2":
                    searchProduct(scanner);
                    break;
                case "3":
                    updateProduct(scanner);
                    break;
                case "4":
                    removeProduct(scanner);
                    break;
                case "5":
                    displayInventoryReport();
                    break;
                case "6":
                    running = false;
                    System.out.println("Exiting the application.");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
        scanner.close();
    }

    private static void displayMenu() {
        System.out.println("\nINVENTORY MANAGEMENT SYSTEM");
        System.out.println("================================");
        System.out.println("(1) Add a new product");
        System.out.println("(2) Search for a product");
        System.out.println("(3) Update a product");
        System.out.println("(4) Remove a product");
        System.out.println("(5) Display inventory report");
        System.out.println("(6) Exit Application");
        System.out.print("Please select one of the above options: ");
    }

    private static void addNewProduct(Scanner scanner) {
        System.out.println("ADD A NEW PRODUCT");
        System.out.print("Enter product type (1 for Electronic, 2 for Grocery): ");
        int type = Integer.parseInt(scanner.nextLine());

        System.out.print("Enter the product id: ");
        String id = scanner.nextLine();

        System.out.print("Enter the product name: ");
        String name = scanner.nextLine();

        System.out.print("Enter the product price: ");
        double price = Double.parseDouble(scanner.nextLine());

        System.out.print("Enter the product quantity: ");
        int quantity = Integer.parseInt(scanner.nextLine());

        if (type == 1) {
            System.out.print("Enter the warranty period (months): ");
            int warrantyPeriod = Integer.parseInt(scanner.nextLine());
            Electronic newElectronic = new Electronic(id, name, price, quantity, warrantyPeriod);
            inventory.add(newElectronic);
        } else if (type == 2) {
            System.out.print("Enter the expiration date (YYYY-MM-DD): ");
            String expirationDate = scanner.nextLine();
            Grocery newGrocery = new Grocery(id, name, price, quantity, expirationDate);
            inventory.add(newGrocery);
        }

        System.out.println("Product added successfully.");
    }

    private static void searchProduct(Scanner scanner) {
        System.out.print("Enter the product id to search: ");
        String id = scanner.nextLine();
        for (Product product : inventory) {
            if (product.getId().equals(id)) {
                System.out.println("Product found:");
                product.displayProduct();
                return;
            }
        }
        System.out.println("Product not found.");
    }

    private static void updateProduct(Scanner scanner) {
        System.out.print("Enter the product id to update: ");
        String id = scanner.nextLine();
        for (Product product : inventory) {
            if (product.getId().equals(id)) {
                System.out.println("Product found:");
                product.displayProduct();

                System.out.print("Enter new name (leave blank to keep current): ");
                String name = scanner.nextLine();
                if (!name.isBlank()) product.setName(name);

                System.out.print("Enter new price (leave blank to keep current): ");
                String price = scanner.nextLine();
                if (!price.isBlank()) product.setPrice(Double.parseDouble(price));

                System.out.print("Enter new quantity (leave blank to keep current): ");
                String quantity = scanner.nextLine();
                if (!quantity.isBlank()) product.setQuantity(Integer.parseInt(quantity));

                if (product instanceof Electronic) {
                    System.out.print("Enter new warranty period (leave blank to keep current): ");
                    String warrantyPeriod = scanner.nextLine();
                    if (!warrantyPeriod.isBlank())
                        ((Electronic) product).setWarrantyPeriod(Integer.parseInt(warrantyPeriod));
                } else if (product instanceof Grocery) {
                    System.out.print("Enter new expiration date (leave blank to keep current): ");
                    String expirationDate = scanner.nextLine();
                    if (!expirationDate.isBlank()) ((Grocery) product).setExpirationDate(expirationDate);
                }

                System.out.println("Product updated successfully.");
                return;
            }
        }
        System.out.println("Product not found.");
    }

    private static void removeProduct(Scanner scanner) {
        System.out.print("Enter the product id to remove: ");
        String id = scanner.nextLine();
        for (Product product : inventory) {
            if (product.getId().equals(id)) {
                inventory.remove(product);
                System.out.println("Product removed successfully.");
                return;
            }
        }
        System.out.println("Product not found.");
    }

    private static void displayInventoryReport() {
        System.out.println("\nINVENTORY REPORT");
        System.out.println("================================");
        for (Product product : inventory) {
            product.displayProduct();
            System.out.println();
        }
    }
    
    
}

