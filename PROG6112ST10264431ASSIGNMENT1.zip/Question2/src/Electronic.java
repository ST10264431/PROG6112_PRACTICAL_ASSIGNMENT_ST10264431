/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

public class Electronic extends Product {
    private int warrantyPeriod; // In months

    // Constructor
    public Electronic(String id, String name, double price, int quantity, int warrantyPeriod) {
        super(id, name, price, quantity);
        this.warrantyPeriod = warrantyPeriod;
    }

    public int getWarrantyPeriod() {
        return warrantyPeriod;
    }

    public void setWarrantyPeriod(int warrantyPeriod) {
        this.warrantyPeriod = warrantyPeriod;
    }

    @Override
    public void displayProduct() {
        super.displayProduct();
        System.out.println("Warranty Period: " + warrantyPeriod + " months");
    }
}
